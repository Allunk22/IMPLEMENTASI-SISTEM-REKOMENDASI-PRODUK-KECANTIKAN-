from pymongo import MongoClient
from collections import Counter
from itertools import combinations

# Koneksi ke MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["ecommerce"]

# Ambil semua riwayat pembelian user
riwayat = db.users.find({}, {"riwayat_pembelian": 1, "_id": 0})

# Hitung pasangan produk yang sering dibeli bersama
pasangan_counter = Counter()
for user in riwayat:
    produk = user.get("riwayat_pembelian", [])
    for pasangan in combinations(sorted(set(produk)), 2):
        pasangan_counter[pasangan] += 1

# Tampilkan hasil lengkap berdasarkan dokumen produk
print("Produk yang sering dibeli bersamaan:\n")
for (p1_id, p2_id), jumlah in pasangan_counter.most_common():
    produk1 = db.produk.find_one({"_id": p1_id})
    produk2 = db.produk.find_one({"_id": p2_id})

    print(f"Pasangan Produk (dibeli bersama oleh {jumlah} user):")
    print(f"\nproduk1 = {produk1}\n")
    print(f"produk2 = {produk2}\n")
    print("=" * 60)
